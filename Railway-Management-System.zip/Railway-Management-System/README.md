# Railway Management System 🚆

**ASP.NET Web Forms · C# · SQL Server · Bootstrap · ADO.NET**

A database-backed railway reservation web application built as a full-stack academic project. Passengers can create accounts, sign in, search train schedules, book seats, review reservations, cancel bookings, submit feedback, and use reward points.

## Features

| Area | Functionality |
|---|---|
| Accounts | Registration, sign-in, session-based passenger profile |
| Search | Routes, destinations, dates, available seats |
| Booking | Passenger count, ticket class, reservation storage, seat updates |
| Profile | Passenger details, booking history, cancellation, profile image |
| Engagement | Reviews and reward-point workflows |
| Data | SQL Server relational tables with primary and foreign keys |

## Technology

- **Frontend:** ASP.NET Web Forms (`.aspx`), HTML, CSS, Bootstrap
- **Backend:** C# code-behind, .NET Framework 4.7.2, ADO.NET (`SqlClient`)
- **Database:** Microsoft SQL Server
- **Development:** Visual Studio and IIS Express

## Project layout

```text
Railway Management System.sln
Railway Management System/     # ASP.NET application (.aspx, .cs, assets, Web.config)
database/schema.sql           # Clean SQL Server setup and fictional routes
SQLQuery1.sql                 # Pointer to corrected setup
README.md
.gitignore
```

## Getting started

1. Install **Visual Studio** with ASP.NET/.NET Framework development support, **.NET Framework 4.7.2 targeting pack**, and **SQL Server** (SQL Server Express is suitable).
2. In SQL Server Management Studio, run `database/schema.sql` on a fresh local SQL Server instance. The script creates `RailwaySystem` and its tables, including the `Booking` table used by the application.
3. Open `Railway Management System.sln` in Visual Studio. Restore NuGet packages when prompted (the `packages/` folder is intentionally excluded).
4. Edit the `sqlCon1` connection string in `Railway Management System/Web.config` for your own SQL Server instance. The checked-in example uses `.\SQLEXPRESS` and Windows authentication.
5. Build and run with **IIS Express**. Register a new passenger account to sign in. The database script intentionally includes **no sample users**.

> This project targets Windows/.NET Framework. The setup has been prepared from source but has **not** been compiled or end-to-end tested against SQL Server in this environment.

## Data model

Core tables: `Traveller`, `Schedule`, `Booking`, and `Reviews`. Supporting tables: `Experience`, `Staff`, `TrainCategories`, `TrainDetails`, `Destinations`, and `TrainDestinations`.

`Booking` references a passenger and a scheduled ride. `Reviews` references a passenger. `Schedule.Available_Seats` tracks remaining capacity.

## Security and reliability

- Registration now saves **PBKDF2 salted password hashes**; login verifies these hashes. Old plaintext-password accounts are **not supported** and must be recreated or migrated securely.
- The supplied real-looking sample identities and plaintext passwords were removed from the published SQL setup.
- The machine-specific connection string was replaced with a local example.
- **Not production-ready:** booking, cancellation, and points updates are not consistently transactional; concurrent seat reservations can race. A production deployment should add SQL transactions, atomic capacity checks, stronger authorization, validation, and security testing.

## Current limitations

- Designed for local IIS Express development; cloud deployment is not configured.
- Route examples use future dates generated at setup time; no automated schedule import.
- SQL schema has been aligned with the app's primary queries, but live runtime compatibility remains unverified.
- Some interface workflows and legacy code require further validation and hardening.

## Future improvements

Transactional booking/cancellation, concurrency-safe seat allocation, automated tests, email confirmations, administrative controls, payment integration, and modern ASP.NET Core migration.

## Project status

Academic full-stack web and relational database development project.
