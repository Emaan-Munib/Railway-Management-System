﻿<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="Experience.aspx.cs" Inherits="Railway_Management_System.Experience" %>

<!DOCTYPE html>

<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <title>Experience</title>
    <style>  
h1 {color: white;}
body {
		background-color: #1E0122;
		background-image: linear-gradient(rgba(0,0,0,0.5),rgba(0,0,0,0.5)),url("https://i.pinimg.com/736x/0a/c9/aa/0ac9aa2ec5567e8aad7d16cd815b1f97.jpg");
		background-attachment: fixed;
        margin: 0;
        font-family: Arial, sans-serif;
    }
    .navbar {
        background-color: black;
        overflow: hidden;
		justify-content: flex-start;
		display: flex;
		padding-left: 200px;
    }
	.navbar img {
		display: block;
		height: 50px;
		width: 90px;
        position: absolute;
		left: 0;
		top: 0;
        margin-top: 20px;
    }
    .navbar a {
        margin: 0; /* Reset default margins */
            float: left;
            display: block;
            color: red;
            padding: 15px 20px;
            text-decoration: none;
            margin-right: 20px;
            width: calc(100% - 4px); /* Reduce width by 4px (2px on each side) */
            height: calc(20px - 4px);
    }
    .navbar a:hover {
         border: 1px solid red; /* Red border on hover */
         line-height: normal; /* Prevent line-height changes */
    }
	.navbar .right {
        margin-left: 250px;
        white-space: nowrap;
    }
	
	 .main-content {
        display: flex;
        flex-wrap: wrap;
		margin-top: 100px;
    }
    .column {
        flex: 1;
        padding: 0px;
    }
    .column img {
		padding: 50px;
        width: 700px;
        height: 520px;
    }
    .column.text {
        color: white;
        padding: 20px;
        box-shadow: 0 2px 4px rgba(0,0,0,0.1);
    }



    .main-content3 {
    flex-wrap: wrap;
    margin-top: 100px;
    display: flex;
    justify-content: center; /* Align items horizontally */
    align-items: center; /* Align items vertically */
}

.column3 {
    flex: 1;
    padding: 0px;
}

.column3 img {
    width: 50%; /* Adjust image width */
    height: auto; /* Maintain aspect ratio */
    max-width: 700px; /* Set maximum width */
    max-height: 520px; /* Set maximum height */
}

.column.text3 {
    background-color: #9B08FF;
    background-image: url("https://wallpapers.com/images/high/solid-color-dark-red-7239j4usg8khw9u7.webp");
    background-attachment: fixed;
    background-size: cover;
    color: white;
    padding: 20px; /* Add padding for better readability */
    box-shadow: 0 2px 4px rgba(0,0,0,0.1);
    flex: 1;
    margin: 20px; /* Add margin for spacing */
}



.main-content4 {
    flex-wrap: wrap;
    margin-top: 100px;
    display: flex;
    justify-content: center; /* Align items horizontally */
    align-items: center; /* Align items vertically */
}

.column4 {
    flex: 1;
    padding: 0px;
}

.column4 img {
    width: 700px;
    height: auto;
    max-width: 100%; /* Ensure image doesn't exceed container width */
    max-height: 520px; /* Set maximum height */
}

.column.text4 {
    background-color: #9B08FF;
    background-image: url("https://wallpapers.com/images/high/solid-color-dark-red-7239j4usg8khw9u7.webp");
    background-attachment: fixed;
    background-size: cover;
    color: white;
    padding: 20px; /* Add padding for better readability */
    box-shadow: 0 2px 4px rgba(0,0,0,0.1);
    flex: 1;
    margin: 20px; /* Add margin for spacing */
}


footer {
        background-color: black;
        color: red;
        text-align: left;
        padding: 20px;
		margin-top: 100px;
    }

</style>
</head>
<body>
    <div class="navbar">
        <img src="https://as2.ftcdn.net/v2/jpg/03/69/35/41/1000_F_369354109_p0zYosnrShhVAdq3og9akg6OiEDSG57w.jpg" alt="Logo" />
        <a href="Main Page.aspx">Home</a>
        <a href="Booking.aspx">Book</a>
        <a href="Experience.aspx">Experience</a>
        <a href= "Reward System.aspx">Rewards</a>	
        <a href = "Staff.aspx">Staff</a>
        <a href = "Reviews.aspx">Reviews</a>
        <asp:HyperLink ID="lnk" class="right" runat="server" Text=""></asp:HyperLink>
    </div>


    <div class="main-content">
        <div class="column text">
            <b><h1 style="text-align:center; padding:40px; color: red">Experience Perfection: Your Ticket to Unmatched Excellence</h1></b>
        </div>
    </div>





<div class="main-content3">
	<div class="column text3">
		<h1> Embark on a Journey Beyond Speed: Where Luxury Meets Landscape</h1>
        <p>Royal Railways' fast-moving trains are among the elite few that can reach speeds of up to 350 mph, setting them apart from conventional train services.<br/>
		This remarkable speed not only reduces travel time but also enhances the thrill of the journey, providing passengers with an exhilarating 
		and unforgettable experience.</p>
    </div>
    <div class="column">
        <img src="Images\shutterstock_1672556236-ezgif.com-webp-to-jpg-converter.jpg" alt="Fast Train"/>
    </div>
</div>




<div class="main-content4">
	<div class="column4">
        <img src="Images\highend-train-with-leather-seats-fine-dining-luxurious-bath-experience_124507-107589.jpg" alt="Fine Dining" />
    </div>
	<div class="column text4">
		<h1> Taste the Journey: Indulge in 5-Star Dining on Rails</h1>
        <p>
Royal Railways' dining facilities redefine the onboard culinary experience, offering passengers a journey of gastronomic delight. <br/>
 From gourmet meals prepared by top chefs to impeccable service in elegant dining cars, every aspect of the dining experience is crafted to perfection. <br/>
 Passengers can savor a wide array of exquisite dishes, carefully curated to reflect the local flavors and culinary traditions of the regions traversed. <br/>
 The ambiance of the dining cars, with their luxurious décor and panoramic views, adds to the charm, creating a dining experience that is both memorable and unique. <br/>
Whether enjoying a leisurely breakfast as the countryside rolls by or indulging in a sumptuous dinner under the stars, dining on Royal Railways is an experience that 
lingers long after the journey ends.</p>
    </div>
</div>



<div class="main-content3">
	<div class="column text3">
		<h1> Journey in Bliss: Where Every Cabin Feels Like Home</h1>
        <p>Royal Railways' cabins redefine the notion of comfort and relaxation, offering passengers a haven on the move.  <br/>
		Each cabin is a sanctuary of luxury, designed to provide a peaceful retreat amidst the journey's excitement. <br/>
		From plush bedding to thoughtful amenities, every detail is tailored to enhance the passenger's comfort. <br/>
		The cabins' cozy ambiance, coupled with the gentle rhythm of the train, creates a soothing environment that is perfect for unwinding. <br/>
		Whether traveling solo or with family, the cabins offer a private oasis where passengers can relax, recharge, and make memories that last a lifetime.</p>
    </div>
    <div class="column">
        <img src="Images\230302093759-01-royal-scotsman-belmond-suites.jpg" alt="Comfortable Cabins"/>
    </div>
</div>

<h1 style="padding:40px; color:red"> Destinations </h1>



<div class="main-content4">
	<div class="column4">
        <img src="Images\Blog-BANNER-25th-Jan-1-1080x700-ezgif.com-webp-to-jpg-converter.jpg" alt="Lahore" />
    </div>
	<div class="column text4">
		<h1> Discover Lahore: Where Every Street Tells a Story</h1>
        <p> Visiting Lahore is a journey through time, where the vibrant present meets a rich, storied past. 
 This city, steeped in history and culture, offers a glimpse into Pakistan's heritage unlike any other. <br/>
 From the majestic Lahore Fort to the bustling streets of the Walled City, every corner is a testament to the city's resilience and splendor. <br/>
 Lahore's cuisine is a culinary adventure in itself, with flavors that tantalize the taste buds and leave a lasting impression. <br/>
 Beyond its historical and gastronomic wonders, Lahore is a city of warmth and hospitality, where visitors are welcomed with open arms. <br/>
 A visit to Lahore is not just a trip; it's an experience that lingers in the heart and soul.</p>
    </div>
</div>



<div class="main-content3">
	<div class="column text3">
		<h1>Experience Islamabad: Where Modernity Meets Tradition</h1>
        <p>Visiting Islamabad offers a unique blend of modernity and natural beauty.
		As the capital of Pakistan, it's a city of contrasts, where modern architecture coexists with lush greenery and picturesque landscapes. <br/>
		The city's well-planned layout and peaceful atmosphere make it a haven for travelers seeking a break from the hustle and bustle of daily life. <br/>
		Islamabad is also home to a rich cultural heritage, with museums, art galleries, and cultural centers that showcase Pakistan's history and traditions.<br/>
		Whether you're exploring the Margalla Hills National Park, visiting the iconic Faisal Mosque, or simply enjoying a stroll in one of the city's many parks, 
		Islamabad offers a refreshing and unforgettable experience for visitors.</p>
    </div>
    <div class="column">
        <img src="Images\925895_9539798_Islamabad2_akhbar.jpg" alt="Islamabad"/>
    </div>
</div>




<div class="main-content4">
	<div class="column4">
        <img src="Images\Karachi-Pakistan-ezgif.com-webp-to-jpg-converter.jpg" alt="Karachi" />
    </div>
	<div class="column text4">
		<h1>Karachi Awaits: Your Gateway to Pakistan's Heartbeat</h1>
        <p>Visiting Karachi offers a dynamic and diverse experience that reflects the essence of Pakistan's culture and commerce.
		As the country's largest and most populous city, Karachi is a melting pot of cultures, languages, and traditions. <br/>
		Its vibrant streets are alive with the hustle and bustle of daily life, offering a glimpse into the heart of Pakistan's urban culture. <br/>
		Karachi's rich history is evident in its architecture, from colonial-era buildings to modern skyscrapers, showcasing the city's evolution over time.<br/>
		The city's culinary scene is equally diverse, with a wide range of flavors and dishes to tantalize the taste buds.<br/>
		Whether you're exploring the historic sites of the old city, soaking in the sun at Clifton Beach, or sampling the local street food,
		Karachi promises an exciting and unforgettable experience for visitors.</p>
    </div>
</div>

<h1 style="padding:40px; color:red"> And Many More </h1>

<footer>
	<h2> Contact Us </h2>
	<p> Telephone Number: 145-423-8724 </p>
	<p> Email: info@royalrailways.com </p>
    <a href="Main Page.aspx" style="color:red; text-decoration:none;">Home</a> <br/> <br/>
    <a href="Booking.aspx" style="color:red; text-decoration:none;">Book</a> <br/> <br/>
    <a href="Experience.aspx" style="color:red; text-decoration:none;">Experience</a> <br/> <br/>
    <a href="Reward System.aspx" style="color:red; text-decoration:none;">Rewards</a> <br/> <br/>
	<a href="Staff.aspx" style="color:red; text-decoration:none;">Staff</a> <br/> <br/>
	<a href="Reviews.aspx" style="color:red; text-decoration:none;">Reviews</a> <br/> <br/>
    <p> All Terms and Conditions Applied </p>
</footer>
</body>
</html>