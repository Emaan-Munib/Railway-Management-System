﻿<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="Reward System.aspx.cs" Inherits="Railway_Management_System.Reward_System" %>

<!DOCTYPE html>

<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <title>Rewards</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" />
  <style>
    body {
      background-color: #1E0122;
		background-image: linear-gradient(rgba(0,0,0,0.5),rgba(0,0,0,0.5)),url("https://i.pinimg.com/736x/0a/c9/aa/0ac9aa2ec5567e8aad7d16cd815b1f97.jpg");
		background-attachment: fixed;
        margin: 0;
        font-family: Arial, sans-serif;
    }
	.navbar {
        background-color: black;
        overflow: hidden;
		justify-content: flex-start;
		display: flex;
		padding-left: 200px;
		height: 50px;
    }
	.navbar img {
		display: block;
		height: 50px;
		width: 90px;
        position: absolute;
		left: 0;
		top: 0;
    }
    .navbar a {
        float: left;
        display: black;
        color: red; /* Change text color to red */
        padding: 5px 20px;
        text-decoration: none;
		margin-right: 20px;
    }
    .navbar a:hover {
        border: 1px solid red; /* Red border on hover */
        line-height: normal; /* Prevent line-height changes */
    }
	.navbar .right {
        margin-left: 200px;
        white-space: nowrap;
    }
    .container {
      background-color: #7810A3;
      border-radius: 5px;
      padding: 30px;
	  color: white;
    }
    .btn-primary {
      background-color: #6c5ce7;
      border-color: #6c5ce7;
    }
    .btn-primary:hover {
       background-color: #4834d4;
      border-color: #4834d4;
    }


    .main-content {
        flex-wrap: wrap;
        margin-top: 100px;
        display: flex;
        justify-content: center; /* Align items horizontally */
        align-items: center; /* Align items vertically */
    }
    
    .column {
        flex: 1;
        padding: 0px;
    }
    
    .column.text {
        background-color: red;
        background-image: url("https://wallpapers.com/images/high/solid-color-dark-red-7239j4usg8khw9u7.webp");
        background-attachment: fixed;
        background-size: cover;
        color: white; /* Change text color to red */
        padding: 20px; /* Add padding for better readability */
        box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        flex: 1;
        margin: 20px; /* Add margin for spacing */
    }


	footer {
        background-color: black;
        color: red;
        text-align: left;
        padding: 20px;
		margin-top: 100px;
    }
  </style>
</head>
<body>
    <div class="navbar">
<img src="https://as2.ftcdn.net/v2/jpg/03/69/35/41/1000_F_369354109_p0zYosnrShhVAdq3og9akg6OiEDSG57w.jpg" alt="Logo" />
<a href="Main Page.aspx">Home</a>
<a href="Booking.aspx">Book</a>
<a href="Experience.aspx">Experience</a>
<a href= "Reward System.aspx">Rewards</a>	
<a href = "Staff.aspx">Staff</a>
<a href = "Reviews.aspx">Reviews</a>
<asp:HyperLink ID="lnk" class="right" runat="server" Text=""></asp:HyperLink>
  </div>


  <div class="main-content">
    <div class="column text">
        <h1>Railway Rewards Program</h1>
        <p>Join our Railway Rewards program to earn points every time you travel with us. Redeem your points for discounts, free tickets, and more!</p>
        <h3>Benefits of Joining:</h3>
        <ul>
            <li>Earn points for every journey</li>
            <li>Exclusive discounts and offers</li>
            <li>Priority booking</li>
            <li>Free upgrades</li>
        </ul>
        <h3>How It Works:</h3>
        <ol>
            <li>Sign up for Railway Rewards online or at our ticket counters.</li>
            <li>Enter your Rewards ID when booking tickets online or provide it at the ticket counter.</li>
            <li>Earn points with every journey.</li>
            <li>Redeem points for rewards.</li>
        </ol>
        <div class="text-center mt-4">
            <form runat="server">
                <asp:Button class="btn btn-primary btn-lg" runat="server" id="jb" Text="" OnClick="jb_Click" />
            </form>
        </div>
    </div>
    <div class="column">
        <img src="Images\p3.jpg" alt="Train Rewards" class="img-fluid rounded mb-4" />
    </div>
</div>

  
  <footer>
	<h2> Contact Us </h2>
	<p> Telephone Number: 145-423-8724 </p>
	<p> Email: info@royalrailways.com </p>
    <a href="Main Page.aspx" style="color:red; text-decoration:none;">Home</a> <br/> <br/>
    <a href="Booking.aspx" style="color:red; text-decoration:none;">Book</a> <br/> <br/>
    <a href="Experience.aspx" style="color:red; text-decoration:none;">Experience</a> <br/> <br/>
    <a href="Reward System.aspx" style="color:red; text-decoration:none;">Rewards</a> <br/> <br/>
	<a href="Staff.aspx" style="color:red; text-decoration:none;">Staff</a> <br/> <br/>
	<a href="Reviews.aspx" style="color:red; text-decoration:none;">Reviews</a> <br/> <br/>
    <p> All Terms and Conditions Applied </p>
</footer>
  
</body>
</html>