﻿<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="Main Page.aspx.cs" Inherits="Railway_Management_System.Main_Page" %>

<!DOCTYPE html>

<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <title>Royal Railways</title>
    <style>  
h1 {color: white;}
body {
		background-color: #1E0122;
		background-image: linear-gradient(rgba(0,0,0,0.5),rgba(0,0,0,0.5)),url("https://i.pinimg.com/736x/0a/c9/aa/0ac9aa2ec5567e8aad7d16cd815b1f97.jpg");
        background-attachment: fixed;
        margin: 0;
        font-family: Arial, sans-serif;
    }
    .navbar {
        background-color: black;
        overflow: hidden;
		justify-content: flex-start;
		display: flex;
		padding-left: 200px;
        margin-top: 20px;
    }
	.navbar img {
		display: block;
		height: 50px;
		width: 90px;
        position: absolute;
		left: 0;
		top: 0;
        margin-top: 20px;
    }
        .navbar a {
            margin: 0; /* Reset default margins */
            float: left;
            display: block;
            color: red;
            padding: 15px 20px;
            text-decoration: none;
            margin-right: 20px;
            width: calc(100% - 4px); /* Reduce width by 4px (2px on each side) */
            height: calc(20px - 4px);
        }
            .navbar a:hover {
                border: 1px solid red; /* Red border on hover */
                line-height: normal; /* Prevent line-height changes */
            }
	.navbar .right {
        margin-left: 250px;
        white-space: nowrap;
    }
	
     .main-content {
    display: flex;
    flex-wrap: wrap;
	margin-top: 30px;
}
    .column {
    flex: 1;
    display: flex;
    justify-content: center; 
    align-items: center; 
    padding: 20px;
}
.column img {
    width: 1000px;
    height: 600px;
}
.column.text {
	
	background-image: rgba(0, 0, 0, 0.5),url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='100%25' height='100%25' viewBox='0 0 1200 800'%3E%3Cdefs%3E%3ClinearGradient id='a' gradientUnits='userSpaceOnUse' x1='600' y1='25' x2='600' y2='777'%3E%3Cstop offset='0' stop-color='%239B08FF'/%3E%3Cstop offset='1' stop-color='%23EB2FFF'/%3E%3C/linearGradient%3E%3ClinearGradient id='b' gradientUnits='userSpaceOnUse' x1='650' y1='25' x2='650' y2='777'%3E%3Cstop offset='0' stop-color='%23a30cff'/%3E%3Cstop offset='1' stop-color='%23c923fc'/%3E%3C/linearGradient%3E%3ClinearGradient id='c' gradientUnits='userSpaceOnUse' x1='700' y1='25' x2='700' y2='777'%3E%3Cstop offset='0' stop-color='%23ab0fff'/%3E%3Cstop offset='1' stop-color='%23a317f9'/%3E%3C/linearGradient%3E%3ClinearGradient id='d' gradientUnits='userSpaceOnUse' x1='750' y1='25' x2='750' y2='777'%3E%3Cstop offset='0' stop-color='%23b313ff'/%3E%3Cstop offset='1' stop-color='%237c0bf6'/%3E%3C/linearGradient%3E%3ClinearGradient id='e' gradientUnits='userSpaceOnUse' x1='800' y1='25' x2='800' y2='777'%3E%3Cstop offset='0' stop-color='%23bb16ff'/%3E%3Cstop offset='1' stop-color='%23550ce6'/%3E%3C/linearGradient%3E%3ClinearGradient id='f' gradientUnits='userSpaceOnUse' x1='850' y1='25' x2='850' y2='777'%3E%3Cstop offset='0' stop-color='%23c21aff'/%3E%3Cstop offset='1' stop-color='%23350ed5'/%3E%3C/linearGradient%3E%3ClinearGradient id='g' gradientUnits='userSpaceOnUse' x1='900' y1='25' x2='900' y2='777'%3E%3Cstop offset='0' stop-color='%23ca1dff'/%3E%3Cstop offset='1' stop-color='%23190fc5'/%3E%3C/linearGradient%3E%3ClinearGradient id='h' gradientUnits='userSpaceOnUse' x1='950' y1='25' x2='950' y2='777'%3E%3Cstop offset='0' stop-color='%23d121ff'/%3E%3Cstop offset='1' stop-color='%23101fb5'/%3E%3C/linearGradient%3E%3ClinearGradient id='i' gradientUnits='userSpaceOnUse' x1='1000' y1='25' x2='1000' y2='777'%3E%3Cstop offset='0' stop-color='%23d824ff'/%3E%3Cstop offset='1' stop-color='%231133a5'/%3E%3C/linearGradient%3E%3ClinearGradient id='j' gradientUnits='userSpaceOnUse' x1='1050' y1='25' x2='1050' y2='777'%3E%3Cstop offset='0' stop-color='%23de28ff'/%3E%3Cstop offset='1' stop-color='%23124295'/%3E%3C/linearGradient%3E%3ClinearGradient id='k' gradientUnits='userSpaceOnUse' x1='1100' y1='25' x2='1100' y2='777'%3E%3Cstop offset='0' stop-color='%23e52bff'/%3E%3Cstop offset='1' stop-color='%23124d86'/%3E%3C/linearGradient%3E%3ClinearGradient id='l' gradientUnits='userSpaceOnUse' x1='1150' y1='25' x2='1150' y2='777'%3E%3Cstop offset='0' stop-color='%23EB2FFF'/%3E%3Cstop offset='1' stop-color='%23125477'/%3E%3C/linearGradient%3E%3C/defs%3E%3Cg fill-opacity='0.63'%3E%3Crect fill='url(%23a)' width='1200' height='800'/%3E%3Crect fill='url(%23b)' x='100' width='1100' height='800'/%3E%3Crect fill='url(%23c)' x='200' width='1000' height='800'/%3E%3Crect fill='url(%23d)' x='300' width='900' height='800'/%3E%3Crect fill='url(%23e)' x='400' width='800' height='800'/%3E%3Crect fill='url(%23f)' x='500' width='700' height='800'/%3E%3Crect fill='url(%23g)' x='600' width='600' height='800'/%3E%3Crect fill='url(%23h)' x='700' width='500' height='800'/%3E%3Crect fill='url(%23i)' x='800' width='400' height='800'/%3E%3Crect fill='url(%23j)' x='900' width='300' height='800'/%3E%3Crect fill='url(%23k)' x='1000' width='200' height='800'/%3E%3Crect fill='url(%23l)' x='1100' width='100' height='800'/%3E%3C/g%3E%3C/svg%3E");
	background-attachment: fixed;
	background-size: cover;
    color: red;
    padding: 0px;
    box-shadow: 0 2px 4px rgba(0,0,0,0.1);
}

 .main-content2 {
     display: flex;
    flex-wrap: wrap;
	margin-top: 50px;
    justify-content: center; 
    align-items: center; 
    height: 50vh;
}
 .slideshow-container {
    position: relative;
    max-width: 100%;
    text-align: center;
}
.mySlides {
        display: none;
        width: 100%; /* Ensures the image takes up 100% of the width of its container */
    height: 400px;

}
.column2 {  
    flex: 1;
    display: flex;
    justify-content: center; 
    align-items: center; 
    padding: 20px;
}
.column2 img {
    width: 700px;
    height: 520px;
}
.column.text2 {
	background-color: red;
	background-image: url("https://wallpapers.com/images/high/solid-color-dark-red-7239j4usg8khw9u7.webp");
    background-attachment: fixed;
	background-size: cover;
    color: white;
    padding: 0px;
    box-shadow: 0 2px 4px rgba(0,0,0,0.1);
}

 .main-content3 {
    display: flex;
    flex-wrap: wrap;
	margin-top: 100px;
}
.column3 {
    flex: 1;
    padding: 0px;
}
.column3 img {
    width: 700px;
    height: 520px;
}
.column.text3 {
	background-color: #9B08FF;
	background-image: url("https://wallpapers.com/images/high/solid-color-dark-red-7239j4usg8khw9u7.webp");
    background-attachment: fixed;
	background-size: cover;
    color: white;
    padding: 0px;
    box-shadow: 0 2px 4px rgba(0,0,0,0.1);
}

 .main-content4 {
    display: flex;
    flex-wrap: wrap;
	margin-top: 100px;
}
.column4 {
    flex: 1;
    padding: 0px;
}
.column4 img {
    width: 700px;
    height: 520px;
}
.column.text4 {
	background-color: #9B08FF;
	background-image: url("https://wallpapers.com/images/high/solid-color-dark-red-7239j4usg8khw9u7.webp");
    background-attachment: fixed;
	background-size: cover;
    color: white;
    padding: 0px;
    box-shadow: 0 2px 4px rgba(0,0,0,0.1);
}

	footer {
        background-color: black;
        color: red;
        text-align: left;
        padding: 20px;
		margin-top: 100px;
    }
		 .menu {
			margin-top: 150px;
			background-color: black;
            display: flex;
            justify-content: space-between;
            padding: 10px;
            overflow-x: auto;
            white-space: nowrap;
			color: white;
        }

        .menu-item {
            flex: 1;
        }

        .heading {
            padding: 10px;
            cursor: pointer;
        }

        .view {
            display: none;
            padding: 10px;
        }

        .active {
            display: block;
        }

.button-85 {
  padding: 0.6em 2em;
  border: none;
  outline: none;
  color: rgb(255, 255, 255);
  background: #111;
  cursor: pointer;
  position: relative;
  z-index: 0;
  border-radius: 10px;
  user-select: none;
  -webkit-user-select: none;
  touch-action: manipulation;
  margin-top: 25px;
}

.button-85:before {
  content: "";
  background: linear-gradient(
    45deg,
    #ff0000,
    #ff7300,
    #fffb00,
    #48ff00,
    #00ffd5,
    #002bff,
    #7a00ff,
    #ff00c8,
    #ff0000
  );
  position: absolute;
  top: -2px;
  left: -2px;
  background-size: 400%;
  z-index: -1;
  filter: blur(5px);
  -webkit-filter: blur(5px);
  width: calc(100% + 4px);
  height: calc(100% + 4px);
  animation: glowing-button-85 20s linear infinite;
  transition: opacity 0.3s ease-in-out;
  border-radius: 10px;
}

@keyframes glowing-button-85 {
  0% {
    background-position: 0 0;
  }
  50% {
    background-position: 400% 0;
  }
  100% {
    background-position: 0 0;
  }
}

.button-85:after {
  z-index: -1;
  content: "";
  position: absolute;
  width: 100%;
  height: 100%;
  background: #222;
  left: 0;
  top: 0;
  border-radius: 10px;
}

@import  url(https://fonts.googleapis.com/css?family=Montserrat);



.text-input{
  
  position: relative;
  margin-top: 50px;
  
  input[type="text"]
  {
    display: inline-block;
    width: 500px;
    height: 40px;
    box-sizing: border-box;
    outline: none;
    border: 1px solid lightgray;
    border-radius: 3px;
    padding: 10px 10px 10px 100px;
    transition: all 0.1s ease-out;
  }
  
  input[type="text"] + label{
    position: absolute;
    top: 0;
    left: 0;
    bottom: 0;
    height: 40px;
    line-height: 40px;
    color: white;
    border-radius: 3px 0 0 3px;
    padding: 0 20px;
    background: #E03616;
    transform: translateZ(0) translateX(0);
    transition: all 0.3s ease-in;
    transition-delay: 0.2s;
  }
  
  input[type="text"]:focus + label{
    transform: translateY(-120%) translateX(0%);
    border-radius: 3px;
    transition: all 0.1s ease-out;
  }
  
  input[type="text"]:focus{
    padding: 10px;
    transition: all 0.3s ease-out;
    transition-delay: 0.2s;
  }
}

.myGridClass {
  width: 100%;
  /this will be the color of the odd row/
  background-color: #fff;
  margin: 5px 0 10px 0;
  border: solid 1px #525252;
  border-collapse:collapse;
}

/data elements/
.myGridClass td {
  padding: 2px;
  border: solid 1px #c1c1c1;
  color: black;
}

/header elements/
.myGridClass th {
  padding: 4px 2px;
  color: #fff;
  background: #000000;
  border-left: solid 1px #525252;
  font-size: 0.9em;
}

/his will be the color of even row/
.myGridClass .myAltRowClass { background: #fcfcfc repeat-x top; }

/and finally, we style the pager on the bottom/
.myGridClass .myPagerClass { background: #424242; }

.myGridClass .myPagerClass table { margin: 5px 0; }

.myGridClass .myPagerClass td {
  border-width: 0;
  padding: 0 6px;
  border-left: solid 1px #666;
  font-weight: bold;
  color: #fff;
  line-height: 12px;
}

.myGridClass .myPagerClass a { color: #666; text-decoration: none; }

.myGridClass .myPagerClass a:hover { color: #000; text-decoration: none; } 

.e-calendar {
        background-color:darkred;
        color: black;
}


</style>
</head>
<body>
    <div class="navbar">
	<img src="https://as2.ftcdn.net/v2/jpg/03/69/35/41/1000_F_369354109_p0zYosnrShhVAdq3og9akg6OiEDSG57w.jpg" alt="Logo" />
    <a href="Main Page.aspx">Home</a>
    <a href="Booking.aspx">Book</a>
    <a href="Experience.aspx">Experience</a>
	<a href= "Reward System.aspx">Rewards</a>	
	<a href = "Staff.aspx">Staff</a>
	<a href = "Reviews.aspx">Reviews</a>
    <asp:HyperLink ID="lnk" class="right" runat="server" Text=""></asp:HyperLink>
</div>

<div class="main-content">
    <div class="column text">
        <b><h1 style="text-align: center; color: red;font-size: 60px"> EXPLORE YOUR COMFORT RIDE </h1></b>
    </div>
</div>


<div class="main-content2">
  
     
        <div class="slideshow-container">
            <div class="mySlides fade">
                <img src="https://i.pinimg.com/564x/e7/ba/70/e7ba70148b99c5ef153eaa0c711acffe.jpg" style="width:100%">
            </div>

            <div class="mySlides fade">
                <img src="https://i.pinimg.com/564x/28/70/72/2870728037c437d7b141e51acaea0db7.jpg" style="width:100%">
            </div>

            <div class="mySlides fade">
            <img src="https://i.pinimg.com/564x/16/a5/35/16a5358151107b5a59ae33913422815f.jpg" style="width:100%">
            </div>

             <div class="mySlides fade">
            <img src="https://i.pinimg.com/564x/d2/52/64/d252644821ce2c9923bc01029fe1afbb.jpg" style="width:100%">
            </div>

             <div class="mySlides fade">
            <img src="https://i.pinimg.com/564x/43/0c/4d/430c4d7b9e280361157cb2e47dcd2ccc.jpg" style="width:100%">
            </div>
            
               <div class="mySlides fade">
              <img src="https://i.pinimg.com/564x/34/f3/97/34f3971baedfbe52c1ca3597819b668a.jpg" style="width:100%">
              </div>

            <!-- Next and previous buttons -->
            <a class="prev" onclick="plusSlides(-1)">&#10094;</a>
            <a class="next" onclick="plusSlides(1)">&#10095;</a>
        </div>

        <!-- Dots/bullets -->
        <div style="text-align:center">
            <span class="dot" onclick="currentSlide(1)"></span>
            <span class="dot" onclick="currentSlide(2)"></span>
            <!-- Add more dots as needed -->
        </div>
    </div>

    <script>
        var slideIndex = 0;
        showSlides();

        function showSlides() {
            var i;
            var slides = document.getElementsByClassName("mySlides");
            for (i = 0; i < slides.length; i++) {
                slides[i].style.display = "none";
            }
            slideIndex++;
            if (slideIndex > slides.length) { slideIndex = 1 }
            slides[slideIndex - 1].style.display = "block";
            setTimeout(showSlides, 2000); // Change image every 2 seconds
        }
    </script>


    <form runat="server">
     <asp:ScriptManager ID="ScriptManager1" runat="server"></asp:ScriptManager>
<div class="menu">
       <div class="menu-item">
        <h2 class="heading" data-view="itinerary" style="color: red; background-color: black;"> Itinerary </h2>
        <div id="itinerary-view" class="view" style="background-color: black;">
            <asp:UpdatePanel ID="UpdatePanel2" runat="server" UpdateMode="Conditional">
    <ContentTemplate>
            <div class="text-input">
                <asp:TextBox ID="ArrivalStation" runat="server"></asp:TextBox>
                <asp:Label ID="Label1" runat="server" AssociatedControlID="ArrivalStation">Enter Arrival station</asp:Label>
            </div>
              <div class="text-input">
                <asp:TextBox ID="DestinationStation" runat="server"></asp:TextBox>
                <asp:Label ID="Label2" runat="server" AssociatedControlID="DestinationStation">Enter destination station </asp:Label>
            </div>
            <asp:Button ID="SearchButton" runat="server" CssClass="button-85" Text="Search" OnClick="SearchButton_Click" />
                    <asp:GridView ID="GridView3" runat="server" AutoGenerateColumns="False" CssClass="myGridClass">
             <Columns>
        <asp:BoundField DataField="Arrival" HeaderText="Arrival Station" />
        <asp:BoundField DataField="Destination" HeaderText="Destination Station" />
        <asp:BoundField DataField="TravelDate" HeaderText="Date" DataFormatString="{0:MM/dd/yyyy}" />
        <asp:BoundField DataField="TravelTime" HeaderText="Time" />
        <asp:BoundField DataField="Available_Seats" HeaderText="Available Seats" />
    </Columns>
</asp:GridView>
             </ContentTemplate>
         </asp:UpdatePanel>
        </div>
    </div>

    <div class="menu-item">
        <h2 class="heading" data-view="v-ride" style="color: red; background-color: black;">View Ride</h2>
        <div id="v-ride-view" class="view" style="background-color: black;">
            <asp:UpdatePanel ID="UpdatePanel1" runat="server" UpdateMode="Conditional">
                <ContentTemplate>
            <div class="text-input">
                <asp:TextBox ID="Destination_Station" runat="server"></asp:TextBox>
                <asp:Label ID="Label3" runat="server" AssociatedControlID="Destination_Station">Enter Destination Station</asp:Label>
            </div>
            <asp:Button ID="PurchaseButton" runat="server" CssClass="button-85" Text="View" OnClick="ViewButton_Click" />
            <asp:GridView ID="GridView2" runat="server" AutoGenerateColumns="False" CssClass="myGridClass">
             <Columns>
        <asp:BoundField DataField="Arrival" HeaderText="Arrival Station" />
        <asp:BoundField DataField="Destination" HeaderText="Destination Station" />
        <asp:BoundField DataField="TravelDate" HeaderText="Date" DataFormatString="{0:MM/dd/yyyy}" />
        <asp:BoundField DataField="TravelTime" HeaderText="Time" />
        <asp:BoundField DataField="Available_Seats" HeaderText="Available Seats" />
    </Columns>
</asp:GridView>
             </ContentTemplate>
         </asp:UpdatePanel>
 </div>
    </div>

    <div class="menu-item">
        <h2 class="heading" data-view="schedule" style="color: red; background-color: black;">Schedule</h2>
        <div id="schedule-view" class="view" style="background-color: black;">
            <asp:UpdatePanel ID="ScheduleUpdatePanel" runat="server" UpdateMode="Conditional">
                <ContentTemplate>
            <div class="text-input">
                <asp:Label ID="Label4" runat="server" Text="Select Start Date"></asp:Label>
                <asp:Calendar ID="StartDateCalendar" runat="server" CssClass="e-calendar" OnSelectionChanged="StartDateCalendar_SelectionChanged"></asp:Calendar>
            </div>
            <div class="text-input">
                <asp:Label ID="Label5" runat="server" Text="Select End Date"></asp:Label>
                <asp:Calendar ID="EndDateCalendar" runat="server" CssClass="e-calendar" OnSelectionChanged="EndDateCalendar_SelectionChanged"></asp:Calendar>
            </div>
            <asp:Button ID="ViewScheduleButton" runat="server" CssClass="button-85" Text="View Schedule" OnClick="ViewScheduleButton_Click" />
             <div>
                <asp:GridView ID="GridView1" runat="server" AutoGenerateColumns="False" CssClass="myGridClass">
         <Columns>
             <asp:BoundField DataField="Arrival" HeaderText="Arrival Station" />
             <asp:BoundField DataField="Destination" HeaderText="Destination Station" />
             <asp:BoundField DataField="TravelDate" HeaderText="Departure Date" DataFormatString="{0:MM/dd/yyyy}" />
             <asp:BoundField DataField="TravelTime" HeaderText="Travel Time" />
             <asp:BoundField DataField="Available_Seats" HeaderText="Available Seats" />
         </Columns>
     </asp:GridView>
        </div>
                    </ContentTemplate>
                </asp:UpdatePanel>
        </div>
    </div>
    </div>
</form>

    <script>
        document.addEventListener('DOMContentLoaded', function () {
            const headings = document.querySelectorAll('.heading');
            const views = document.querySelectorAll('.view');

            headings.forEach(function (heading) {
                heading.addEventListener('click', function () {
                    // Hide all views
                    views.forEach(function (view) {
                        view.classList.remove('active');
                    });

                    // Show only the clicked view
                    const viewId = this.getAttribute('data-view');
                    document.getElementById(viewId + '-view').classList.add('active');
                });
            });
        });
    </script>


    <div class="main-content3">
	<div class="column text3">
		<h1> About Royal Railways </h1>
        <p>Welcome to Royal Railways, where we believe in pursuing perfection in everything we do. At Royal Railways, we are not just a railway company;
		we are a symbol of excellence, reliability, and luxury in the transportation industry. <br/> <br/> 
		Since our inception, we have been committed to providing our passengers with <br/> an unparalleled travel experience that is both comfortable and safe.
		Our dedication to perfection is evident in every aspect of our operations. From our meticulously maintained trains to our highly trained staff, 
		we strive to exceed our passengers' expectations at every turn. Whether you are traveling for business or pleasure, you can trust Royal Railways to
		deliver a journey that is nothing short of exceptional. <br/> <br/>
		But our pursuit of perfection extends beyond our services. We are also committed to being a responsible corporate citizen, minimizing our environmental impact
		and giving back to the communities we serve. Through our sustainable practices and community initiatives, we are working to create a better future for all. <br/> <br/>
		Join us on a journey of excellence. Experience the difference of Royal Railways, where perfection is not just a goal, but a way of life.</p>
    </div>
    <div class="column3">
        <img src="https://static.vecteezy.com/system/resources/previews/026/419/459/non_2x/a-train-in-the-snow-with-dark-background-insane-detail-made-by-ai-generative-free-photo.jpg" alt="Image" />
    </div>
</div>

<%--<div class="main-content3">
<div class="column text">
<b><h2 style="text-align: center; color: red;font-size: 60px"> EXPLORE YOUR CHOICES </h2></b>
</div>

</div>--%>

<div class="main-content4">
	<div class="column text4">
		<h1 style = "color:white;"> Our Sustainable Approach </h1>
        <p>Royal Railways is a trailblazer in sustainable development and clean transportation, prioritizing environmental stewardship in its operations.
		The company's approach to sustainability encompasses various facets, including energy efficiency, renewable energy adoption, and waste management. 
		By investing in modern, energy-efficient locomotives and trains,
		Royal Railways not only reduces its carbon footprint but also sets a precedent for the industry. 
		Furthermore, the gradual transition to renewable energy sources like solar power underscores its commitment to clean energy and a greener future. <br/><br/>
		In addition to its operational practices, Royal Railways also focuses on green infrastructure development.
		This includes eco-friendly railway stations and facilities that are designed to minimize environmental impact and enhance sustainability. 
		Moreover, the company actively engages with passengers to raise awareness about sustainable travel practices,
		encouraging them to participate in the journey towards a cleaner, more sustainable future. 
		Through collaboration, innovation, and a steadfast commitment to sustainability, 
		Royal Railways exemplifies how companies can lead the way in promoting environmental responsibility in the transportation sector.</p>
    </div>
    <div class="column4">
        <img src="https://i.pinimg.com/564x/48/51/59/4851597c77d7e0930a97a28a6f2bbcb0.jpg" alt="Image"/>
    </div>
</div>


<footer>
	<h2> Contact Us </h2>
	<p> Telephone Number: 145-423-8724 </p>
	<p> Email: info@royalrailways.com </p>
    <a href="Main Page.aspx" style="color:red; text-decoration:none;">Home</a> <br/> <br/>
    <a href="Booking.aspx" style="color:red; text-decoration:none;">Book</a> <br/> <br/>
    <a href="Experience.aspx" style="color:red; text-decoration:none;">Experience</a> <br/> <br/>
    <a href="Reward System.aspx" style="color:red; text-decoration:none;">Rewards</a> <br/> <br/>
	<a href="Staff.aspx" style="color:red; text-decoration:none;">Staff</a> <br/> <br/>
	<a href="Reviews.aspx" style="color:red; text-decoration:none;">Reviews</a> <br/> <br/>
    <p> All Terms and Conditions Applied </p>
</footer>
</body>
</html>