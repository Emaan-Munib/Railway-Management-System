﻿<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="Booking.aspx.cs" Inherits="Railway_Management_System.Booking" %>

<!DOCTYPE html>

<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <title>Booking</title>
     <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    body {
        background-color: black;
		background-image: linear-gradient(rgba(0,0,0,0.5),rgba(0,0,0,0.5)),url("https://i.pinimg.com/736x/0a/c9/aa/0ac9aa2ec5567e8aad7d16cd815b1f97.jpg");
        background-attachment: fixed;
        margin: 0;
        font-family: Arial, sans-serif;
		color: white;
    }
	.navbar {
    background-color: black;
    overflow: hidden;
	justify-content: flex-start;
	display: flex;
	padding-left: 200px;
    margin-top: 0px;
}
.navbar img {
	display: block;
	height: 60px;
	width: 70px;
    position: absolute;
	left: 0;
	top: 0;
    margin-top: 10px;
    margin-left: 20px;
    
}
.navbar a {
    float: left;
    display: block;
    color: red;
    padding: 15px 20px;
    text-decoration: none;
	margin-right: 20px;
   

}
.navbar a:hover {
    background-color: black;
}
.navbar .right {
    margin-left: 250px;
    white-space: nowrap;
}
	
	
    .container {
      background-color: black;
      border-radius: 10px;
      padding: 30px;
      box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    }
    .btn-primary {
      background-color: #6c5ce7; /* Dark Purple */
      border-color: #6c5ce7;
    }
    .btn-primary:hover {
      background-color: #4834d4; /* Slightly Darker Purple */
      border-color: #4834d4;
    }
	footer {
        background-color: black;
        color: red;
        text-align: left;
        padding: 20px;
		margin-top: 100px;
    }

    .myGridClass {
  width: 100%;
  /this will be the color of the odd row/
  background-color: #fff;
  margin: 5px 0 10px 0;
  border: solid 1px #525252;
  border-collapse:collapse;
}

/data elements/
.myGridClass td {
  padding: 2px;
  border: solid 1px #c1c1c1;
  color: black;
}

/header elements/
.myGridClass th {
  padding: 4px 2px;
  color: #fff;
  background: #000000;
  border-left: solid 1px #525252;
  font-size: 0.9em;
}

/his will be the color of even row/
.myGridClass .myAltRowClass { background: #fcfcfc repeat-x top; }

/and finally, we style the pager on the bottom/
.myGridClass .myPagerClass { background: #424242; }

.myGridClass .myPagerClass table { margin: 5px 0; }

.myGridClass .myPagerClass td {
  border-width: 0;
  padding: 0 6px;
  border-left: solid 1px #666;
  font-weight: bold;
  color: #fff;
  line-height: 12px;
}

.myGridClass .myPagerClass a { color: #666; text-decoration: none; }

.myGridClass .myPagerClass a:hover { color: #000; text-decoration: none; } 

.e-calendar {
        background-color:darkred;
        color: black;
}

.message {
        color: red;
        font-weight: bold;
        margin-top: 10px;
 }

  </style>
</head>
<body>
   <div class="navbar">
<img src="https://as2.ftcdn.net/v2/jpg/03/69/35/41/1000_F_369354109_p0zYosnrShhVAdq3og9akg6OiEDSG57w.jpg" alt="Logo" />
<a href="Main Page.aspx">Home</a>
<a href="Booking.aspx">Book</a>
<a href="Experience.aspx">Experience</a>
<a href= "Reward System.aspx">Rewards</a>	
<a href = "Staff.aspx">Staff</a>
<a href = "Reviews.aspx">Reviews</a>
<asp:HyperLink ID="lnk" class="right" runat="server" Text=""></asp:HyperLink>
       </div>
	
   <form runat="server">
     <asp:ScriptManager ID="ScriptManager1" runat="server"></asp:ScriptManager>
     <div class="container mt-5">
         <h1 class="mb-4 text-center" style="color:red">Ride Booking</h1>
         <asp:UpdatePanel ID="UpdatePanel" runat="server" UpdateMode="Conditional">
             <ContentTemplate>
                 <div class="row">
                     <div class="col-md-6">
                         <asp:Image ID="imgTrain" runat="server" ImageUrl="https://as2.ftcdn.net/v2/jpg/02/95/90/05/1000_F_295900594_QG3JqyYUBXnSPKo6ECYfL4Qn8KfwUgUl.jpg" AlternateText="Train" CssClass="img-fluid mb-4" />
                     </div>
                     <div class="col-md-6">
                         <asp:Image ID="imgBooking" runat="server" ImageUrl="https://as1.ftcdn.net/v2/jpg/01/81/21/64/1000_F_181216408_BOYVX7fiUDiAGeGcWyzDa1G553t7KyrM.jpg" AlternateText="Booking" CssClass="img-fluid mb-4" />
                     </div>
                 </div>
                 <div class="mb-3">
                     <asp:Label ID="lblFrom" runat="server" AssociatedControlID="from" Text="Venue"></asp:Label>
                     <asp:TextBox ID="from" runat="server" CssClass="form-control" placeholder="Enter Venue" AutoPostBack="true" OnTextChanged="from_TextChanged"></asp:TextBox>
                 </div>
                 <div class="mb-3">
                     <asp:Label ID="lblTo" runat="server" AssociatedControlID="to" Text="City"></asp:Label>
                     <asp:TextBox ID="to" runat="server" CssClass="form-control" placeholder="Enter City" AutoPostBack="true" OnTextChanged="to_TextChanged"></asp:TextBox>
                 </div>
                 <div class="text-input">
                     <asp:Label ID="Label4" runat="server" Text="Select Date"></asp:Label>
                     <asp:Calendar ID="Date" runat="server" CssClass="e-calendar" OnSelectionChanged="DateCalendar_SelectionChanged"></asp:Calendar>
                 </div>
                 <div class="text-center">
                     <asp:Button ID="btnSearch" runat="server" Text="Search" CssClass="btn btn-primary" OnClick="btnSearch_Click" />
                 </div>
                 <asp:GridView ID="scheduleGridView" runat="server" CssClass="myGridClass" AutoGenerateColumns="False" AutoGenerateSelectButton="true" EnableViewState="true" OnSelectedIndexChanged="scheduleGridView_SelectedIndexChanged">
                     <SelectedRowStyle BackColor="#738A9C" Font-Bold="True" ForeColor="White" /> 
                     <Columns>
                         <asp:BoundField DataField="RideID" HeaderText="Ride Number" />
                         <asp:BoundField DataField="Arrival" HeaderText="Arrival Station" />
                         <asp:BoundField DataField="Destination" HeaderText="Destination Station" />
                         <asp:BoundField DataField="TravelDate" HeaderText="Date" DataFormatString="{0:MM/dd/yyyy}" />
                         <asp:BoundField DataField="TravelTime" HeaderText="Time" />
                         <asp:BoundField DataField="Available_Seats" HeaderText="Seats_Available" />
                     </Columns>
                 </asp:GridView>
                 <div id="passengersSection" runat="server" visible="false">
                     <div class="mb-3">
                         <div class="text-input">
                              <asp:Label ID="Label3" runat="server" AssociatedControlID="Passengers" Text=""></asp:Label>
                             <asp:TextBox ID="Passengers" runat="server" required></asp:TextBox>
                        </div> 
                     </div>
                     <div class="mb-3">
                         <asp:Label ID="lblClass" runat="server" AssociatedControlID="type" Text="Ticket Class"></asp:Label>
                         <asp:DropDownList ID="type" runat="server" CssClass="form-select">
                             <asp:ListItem Text="Choose..." Selected="True"></asp:ListItem>
                             <asp:ListItem Text="Economy"></asp:ListItem>
                             <asp:ListItem Text="Business"></asp:ListItem>
                         </asp:DropDownList>
                     </div>
                     <div class="mb-3">
                         <asp:Label ID="lblRewards" runat="server" AssociatedControlID="Rewards" Text="Use Points"></asp:Label>
                                <asp:DropDownList ID="Rewards" runat="server" CssClass="form-select">
                                      <asp:ListItem Text="Choose..." Selected="True"></asp:ListItem>
                                      <asp:ListItem Text="Discount"></asp:ListItem>
                                      <asp:ListItem Text="Food"></asp:ListItem>
                                </asp:DropDownList>
                    </div>
                     <asp:Label ID="totalBill" runat="server" Text="Total Bill "></asp:Label> <br /> <br />
                     <asp:Button ID="btnBook" runat="server" Text="Book Now" CssClass="btn btn-primary" OnClick="btnBook_Click" />
                     <asp:Button ID="purchasebtn" runat="server" Text="Purchase" Visible ="false" CssClass="btn btn-primary" OnClick="purchasebtn_Click" />
                     <asp:Label ID="error" runat="server"  Text="" CssClass="message"></asp:Label>
              </div>
             </ContentTemplate>
         </asp:UpdatePanel>
     </div>
 </form>
 
   
<footer>
	<h2> Contact Us </h2>
	<p> Telephone Number: 145-423-8724 </p>
	<p> Email: info@eventhorizon.com </p>
    <a href="Main Page.aspx" style="color:red; text-decoration:none;">Home</a> <br/> <br/>
    <a href="Booking.aspx" style="color:red; text-decoration:none;">Book</a> <br/> <br/>
    <a href="Experience.aspx" style="color:red; text-decoration:none;">Experience</a> <br/> <br/>
    <a href="Reward System.aspx" style="color:red; text-decoration:none;">Rewards</a> <br/> <br/>
	<a href="Staff.aspx" style="color:red; text-decoration:none;">Staff</a> <br/> <br/>
	<a href="Reviews.aspx" style="color:red; text-decoration:none;">Reviews</a> <br/> <br/>
    <p> All Terms and Conditions Applied </p>
</footer>
</body>
</html>