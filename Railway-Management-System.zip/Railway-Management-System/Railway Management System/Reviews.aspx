﻿<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="Reviews.aspx.cs" Inherits="Railway_Management_System.Reviews" %>

<!DOCTYPE html>

<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <title>Reviews</title>
    <style>
    body {
         background-color: #1E0122;
        background-image:  linear-gradient(rgba(0,0,0,0.5),rgba(0,0,0,0.5)),url("https://i.pinimg.com/736x/0a/c9/aa/0ac9aa2ec5567e8aad7d16cd815b1f97.jpg");
        background-attachment: fixed;
        margin: 0;
        font-family: Arial, sans-serif;
        color: white;
    }
    .container {
        max-width: 800px;
        margin: 20px auto;
        padding: 20px;
    }
    h1 {
        text-align: center;
    }
    form {
        margin-bottom: 20px;
    }
    label {
        display: block;
        margin-bottom: 5px;
    }
    input[type="text"],
    textarea {
        width: 100%;
        padding: 10px;
        margin-bottom: 10px;
        background-color: black;
        color: white;
    }
    input[type="submit"] {
        color: red;
        border: none;
        border-radius: 5px;
        padding: 10px 20px;
        cursor: pointer;
        background-color: #6c5ce7;
        /* Dark Purple */
        border-color: #6c5ce7;
    }
    input[type="submit"]:hover {
        background-color: #0056b3;
    }
    .reviews {
        padding-top: 20px;
        border-top: 3px solid #ccc;
    }
    .review {
        margin-bottom: 10px;
        padding-bottom: 10px;
    }
    .review p {
        margin: 5px 0;
    }
    .navbar {
        background-color: black;
        overflow: hidden;
        justify-content: flex-start;
        display: flex;
        padding-left: 200px;
    }
    .navbar img {
        display: block;
        height: 50px;
        width: 90px;
        position: absolute;
        left: 0;
        top: 0;
    }
    .navbar a {
        float: left;
        display: block;
        color: red;
        padding: 15px 20px;
        text-decoration: none;
        margin-right: 20px;
    }
    .navbar a:hover {
        background-color: #7810a3;
    }
    .navbar .right {
        margin-left: 250px;
        white-space: nowrap;
    }
    .reviews {
            margin-top: 20px;
        }

        .review-box {
            padding: 10px;
            margin-bottom: 10px;
        }

        .review-header {
            display: flex;
            justify-content: space-between;
            margin-bottom: 5px;
        }

        .review-name {
            font-weight: bold;
        }

        .review-date {
            color: #888;
            font-size: 0.8em;
        }

        .review-text {
            clear: both;
        }
        footer {
            background-color: black;
            color: red;
            text-align: left;
            padding: 20px;
	        margin-top: 100px;
        }
        .message {
            color: red;
            font-weight: bold;
            margin-top: 10px;
        }
</style>
</head>
<body>
        <div class="navbar">
<img src="https://as2.ftcdn.net/v2/jpg/03/69/35/41/1000_F_369354109_p0zYosnrShhVAdq3og9akg6OiEDSG57w.jpg" alt="Logo" />
<a href="Main Page.aspx">Home</a>
<a href="Booking.aspx">Book</a>
<a href="Experience.aspx">Experience</a>
<a href= "Reward System.aspx">Rewards</a>	
<a href = "Staff.aspx">Staff</a>
<a href = "Reviews.aspx">Reviews</a>
<asp:HyperLink ID="lnk" class="right" runat="server" Text=""></asp:HyperLink>
            </div>
        
    <div class="container">
        <h1>Customer Reviews</h1>
         <asp:Label ID="lblMessage" runat="server" CssClass="message" Text=""></asp:Label>
        <form id="reviewForm" runat="server">
        <label for="review">Review:</label>
        <asp:TextBox ID="reviewInput" runat="server" TextMode="MultiLine"></asp:TextBox>
        <asp:Button ID="submitButton" runat="server" Text="Submit Review" OnClick="SubmitReview" />
    </form>
    <div class="reviews" id="reviews" runat="server">
        <!-- Reviews will be added here dynamically -->
    </div>
        </div>

<footer>
	<h2> Contact Us </h2>
	<p> Telephone Number: 145-423-8724 </p>
	<p> Email: info@royalrailways.com </p>
    <a href="Main Page.aspx" style="color:red; text-decoration:none;">Home</a> <br/> <br/>
    <a href="Booking.aspx" style="color:red; text-decoration:none;">Book</a> <br/> <br/>
    <a href="Experience.aspx" style="color:red; text-decoration:none;">Experience</a> <br/> <br/>
    <a href="Reward System.aspx" style="color:red; text-decoration:none;">Rewards</a> <br/> <br/>
	<a href="Staff.aspx" style="color:red; text-decoration:none;">Staff</a> <br/> <br/>
	<a href="Reviews.aspx" style="color:red; text-decoration:none;">Reviews</a> <br/> <br/>
    <p> All Terms and Conditions Applied </p>
</footer>
</body>
</html>