﻿<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="Staff.aspx.cs" Inherits="Railway_Management_System.Staff" %>

<!DOCTYPE html>

<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <title>Staff</title>
    <style>
  body {
		background-color: #1E0122;
		background-image: linear-gradient(rgba(0,0,0,0.5),rgba(0,0,0,0.5)),url("https://i.pinimg.com/736x/0a/c9/aa/0ac9aa2ec5567e8aad7d16cd815b1f97.jpg");
		background-attachment: fixed;
        margin: 0;
        font-family: Arial, sans-serif;
		color: white;
    }
	
.navbar {
        background-color: black;
        overflow: hidden;
		justify-content: flex-start;
		display: flex;
		padding-left: 200px;
    }
	.navbar img {
		display: block;
		height: 50px;
		width: 90px;
        position: absolute;
		left: 0;
		top: 0;
    }
    .navbar a {
        float: left;
        display: block;
        color: red;
        padding: 15px 20px;
        text-decoration: none;
		margin-right: 20px;
    }
    .navbar a:hover {
        border: 1px solid red; /* Red border on hover */
        line-height: normal; /* Prevent line-height changes */
    }
	.navbar .right {
        margin-left: 250px;
        white-space: nowrap;
    }
	
	
.filter {
  text-align: left;
  margin-top: 50px;
  margin-bottom: 20px;
  margin-left: 25px;
}

.filter label {
  font-weight: bold;
  margin-right: 10px;
  display: inline-block;
  margin-bottom: 5px;
}

.filter select {
  padding: 8px 12px;
  font-size: 15px;
  appearance: none; /* Remove default arrow icon */
  background-color: black;
  color: white;
  cursor: pointer;
  max-width: 100%; /* Ensures select doesn't overflow its container */
  width: auto; /* Ensures select only takes up necessary width */
}

.filter select:hover,
.filter select:focus {
  border-color: #999;
}

.filter select option {
  background-color: #f7f7f7;
  color: #333;
}

.filter select option:checked {
  background-color: #ddd;
}

.filter select option:hover {
  background-color: #eee;
}

  .row {
    display: flex;
    flex-wrap: wrap;
  }

  .person {
    width: calc(33.33% - 20px);
    margin: 10px;
    padding: 10px;
    text-align: center;
    box-sizing: border-box;
  }
  
  .person img {
    width: 300px;
    height: 300px;
    margin-bottom: 10px;
  }

  .staff {
    text-align: left; 
    padding-left: 10px;
  }
  
  footer {
        background-color: black;
        color: red;
        text-align: left;
        padding: 20px;
		margin-top: 100px;
    }
</style>
</head>
<body>
    <div class="navbar">
<img src="https://as2.ftcdn.net/v2/jpg/03/69/35/41/1000_F_369354109_p0zYosnrShhVAdq3og9akg6OiEDSG57w.jpg" alt="Logo" />
<a href="Main Page.aspx">Home</a>
<a href="Booking.aspx">Book</a>
<a href="Experience.aspx">Experience</a>
<a href= "Reward System.aspx">Rewards</a>	
<a href = "Staff.aspx">Staff</a>
<a href = "Reviews.aspx">Reviews</a>
<asp:HyperLink ID="lnk" class="right" runat="server" Text=""></asp:HyperLink>
</div>


<div class="filter">
  <label for="roleFilter" style="color: red;">Filter by Role:</label>
  <select id="roleFilter" style="color: red;">
    <option value="all" style="color: black;">All</option>
    <option value="driver" style="color: black;">Driver</option>
    <option value="conductor" style="color: black;">Conductor</option>
    <option value="engineer" style="color: black;">Engineer</option>
    <option value="operator" style="color: black;">Operator</option>
  </select>
</div>

<div class="staff" id="staff">
  <!-- Person elements will be dynamically added here -->
  <div class="row">
    <div class="person engineer">
      <img src="Images\Professional-Headshot-Vancouver.jpeg" alt="Engineer"/>
      <p style="color: white;">Name: Rana Hamza</p>
      <p style="color: white;">Role: Engineer</p>
    </div>
    <div class="person engineer">
      <img src="https://item24us.news/wp-content/uploads/2021/03/InternationalWomensDayAWEImage.jpg" alt="Engineer"/>
      <p style="color: white;">Name: Ayesha Mughal</p>
      <p style="color: white;">Role: Engineer</p>
    </div>
    <div class="person conductor">
      <img src="https://media.istockphoto.com/id/174635379/photo/young-boy-role-playing-as-a-train-conductor.jpg?s=612x612&w=0&k=20&c=PRRFq9bcswE6qqti-hC36DkT-R9Vf8PRjPjqHQ92BMw=" alt="Conductor"/>
      <p style="color: white;">Name: Ali Warraich</p>
      <p style="color: white;">Role: Conductor</p>
    </div>
    <div class="person driver">
      <img src="https://media.istockphoto.com/id/1211660402/photo/train-engine-driver-occupation-experienced-man-sitting-on-drivers-position-in-subway-train.jpg?s=612x612&w=0&k=20&c=Y1n9bKJ3nExF9Mdyw9soYb-iw4kgg_q3BrjuW3KSTVM=" alt="Driver"/>
      <p style="color: white;">Name: Arshad Jutt</p>
      <p style="color: white;">Role: Driver</p>
    </div>
    <div class="person operator">
      <img src="https://img.koreatimes.co.kr/upload/newsV2/images/04-23-17-03.jpg" alt="Operator"/>
      <p style="color: white;">Name: Mian Ahmad</p>
      <p style="color: white;">Role: Operator</p>
    </div>
  </div>
</div>


<<footer>
	<h2> Contact Us </h2>
	<p> Telephone Number: 145-423-8724 </p>
	<p> Email: info@royalrailways.com </p>
    <a href="Main Page.aspx" style="color:red; text-decoration:none;">Home</a> <br/> <br/>
    <a href="Booking.aspx" style="color:red; text-decoration:none;">Book</a> <br/> <br/>
    <a href="Experience.aspx" style="color:red; text-decoration:none;">Experience</a> <br/> <br/>
    <a href="Reward System.aspx" style="color:red; text-decoration:none;">Rewards</a> <br/> <br/>
	<a href="Staff.aspx" style="color:red; text-decoration:none;">Staff</a> <br/> <br/>
	<a href="Reviews.aspx" style="color:red; text-decoration:none;">Reviews</a> <br/> <br/>
    <p> All Terms and Conditions Applied </p>
</footer>


<script>
    // Store the original list of persons
    const allPersons = document.getElementById('staff').querySelectorAll('.person');

    document.getElementById('roleFilter').addEventListener('change', function () {
        const selectedRole = this.value;
        const staff = document.getElementById('staff');

        // Remove existing elements
        while (staff.firstChild) {
            staff.removeChild(staff.firstChild);
        }

        let filteredPersons = Array.from(allPersons).filter(person => {
            return selectedRole === 'all' || person.classList.contains(selectedRole);
        });

        let row = document.createElement('div');
        row.classList.add('row');

        filteredPersons.forEach((person, index) => {
            if (index % 3 === 0) {
                // Start a new row for every 3 persons
                row = document.createElement('div');
                row.classList.add('row');
                staff.appendChild(row);
            }
            row.appendChild(person);
        });
    });
</script>
</body>
</html>