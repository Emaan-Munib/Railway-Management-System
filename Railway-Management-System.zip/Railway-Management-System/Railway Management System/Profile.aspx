﻿<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="Profile.aspx.cs" Inherits="Railway_Management_System.Profile" %>

<!DOCTYPE html>

<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <title>Profile</title>
      <style>
	body {
		background-color: #1E0122;
		background-image:  linear-gradient(rgba(0,0,0,0.5),rgba(0,0,0,0.5)),url("https://i.pinimg.com/736x/0a/c9/aa/0ac9aa2ec5567e8aad7d16cd815b1f97.jpg");
        background-attachment: fixed;
        margin: 0;
        font-family: Arial, sans-serif;
		color: red;
    }
    .navbar {
        background-color: black;
        overflow: hidden;
		justify-content: flex-start;
		display: flex;
		padding-left: 200px;
    }
	.navbar img {
		display: block;
		height: 50px;
		width: 90px;
        position: absolute;
		left: 0;
		top: 0;
    }
    .navbar a {
        float: left;
        display: block;
        color: red;
        padding: 15px 20px;
        text-decoration: none;
		margin-right: 20px;
    }
    .navbar a:hover {
        background-color: #7810A3;
    }
	.navbar .right {
        margin-left: 250px;
        white-space: nowrap;
    }
	footer {
        background-color: black;
        color: red;
        text-align: left;
        padding: 20px;
		margin-top: 100px;
    }
    .container {
    max-width: 800px;
    margin: 0 auto;
    padding: 20px;
    text-align: center;
}

.profile {
    margin-top: 20px;
    display: flex;
    flex-direction: column;
    align-items: center;
}

.profile img {
    width: 150px;
    height: 150px;
    border-radius: 50%;
    margin-bottom: 10px;
}

.info {
    text-align: left;
}

.info p {
    margin: 5px 0;
}
.btn-primary {
  background-color: #6c5ce7; /* Dark Purple */
  border-color: #6c5ce7;
  cursor: pointer;
}
.btn-primary:hover {
  background-color: #4834d4; /* Slightly Darker Purple */
  border-color: #4834d4;
  cursor: pointer;
}


    .myGridClass {
  width: 100%;
  /this will be the color of the odd row/
  background-color: #fff;
  margin: 5px 0 10px 0;
  border: solid 1px #525252;
  border-collapse:collapse;
}

/data elements/
.myGridClass td {
  padding: 2px;
  border: solid 1px #c1c1c1;
  color: black;
}

/header elements/
.myGridClass th {
  padding: 4px 2px;
  color: #fff;
  background: #000000;
  border-left: solid 1px #525252;
  font-size: 0.9em;
}

/his will be the color of even row/
.myGridClass .myAltRowClass { background: #fcfcfc repeat-x top; }

/and finally, we style the pager on the bottom/
.myGridClass .myPagerClass { background: #424242; }

.myGridClass .myPagerClass table { margin: 5px 0; }

.myGridClass .myPagerClass td {
  border-width: 0;
  padding: 0 6px;
  border-left: solid 1px #666;
  font-weight: bold;
  color: #fff;
  line-height: 12px;
}

.myGridClass .myPagerClass a { color: #666; text-decoration: none; }

.myGridClass .myPagerClass a:hover { color: #000; text-decoration: none; } 

	</style>
</head>
<body>
   <div class="navbar">
<img src="https://as2.ftcdn.net/v2/jpg/03/69/35/41/1000_F_369354109_p0zYosnrShhVAdq3og9akg6OiEDSG57w.jpg" alt="Logo" />
<a href="Main Page.aspx">Home</a>
<a href="Booking.aspx">Book</a>
<a href="Experience.aspx">Experience</a>
<a href= "Reward System.aspx">Rewards</a>	
<a href = "Staff.aspx">Staff</a>
<a href = "Reviews.aspx">Reviews</a>
<asp:HyperLink ID="lnk" class="right" runat="server" Text=""></asp:HyperLink>
	</div>
	
   <form id="form1" runat="server">
            <asp:ScriptManager ID="ScriptManager1" runat="server"></asp:ScriptManager>
    <div class="container">
                <asp:Button class="btn-primary" runat="server" Text="Logout" OnClick="Logout" style="margin-top: 21px; margin-left: 900px" />
            <h1>User Profile</h1>
            <div class="profile">
                <asp:Image ID="profilePhoto" runat="server" CssClass="profile-photo" />
                <div class="info">
                    <p><strong>Full Name:</strong> <asp:Label ID="lblFullName" runat="server"></asp:Label></p>
                    <p><strong>Phone Number:</strong> <asp:Label ID="lblPhoneNumber" runat="server"></asp:Label></p>
                    <p><strong>CNIC:</strong> <asp:Label ID="lblCnic" runat="server"></asp:Label></p>
                    <p><strong>Email:</strong> <asp:Label ID="lblEmail" runat="server"></asp:Label></p>
                    <p><strong>Points:</strong> <asp:Label ID="lblPoints" runat="server"></asp:Label></p>
                </div>
            </div>
            <asp:FileUpload ID="fileToUpload" runat="server" />
            <asp:Button ID="btnUpload" class="btn-primary" runat="server" Text="Upload Photo" OnClick="btnUpload_Click" style="margin-top: 21px" />
           </div>

       <br /> <br />
       <asp:UpdatePanel ID="UpdatePanel" runat="server" UpdateMode="Conditional">
         <ContentTemplate>
       <h2 style="color:white"> Your Bookings</h2>
       <asp:GridView ID="GridViewBookings" runat="server" AutoGenerateColumns="False" CssClass="myGridClass" AutoGenerateSelectButton="true">
            <SelectedRowStyle BackColor="#738A9C" Font-Bold="True" ForeColor="White" />
            <Columns>
                <asp:BoundField DataField="BookingID" HeaderText="Booking ID" />
                <asp:BoundField DataField="RideID" HeaderText="Ride Number" />
                <asp:BoundField DataField="Arrival" HeaderText="Arrival" />
                <asp:BoundField DataField="Destination" HeaderText="Destination" />
                <asp:BoundField DataField="TravelDate" HeaderText="Date" DataFormatString="{0:MM/dd/yyyy}"/>
                <asp:BoundField DataField="TravelTime" HeaderText="Time" />
                <asp:BoundField DataField="Seats" HeaderText="Passengers" />
                <asp:BoundField DataField="Class" HeaderText="Class" />
            </Columns>
        </asp:GridView>
                         <asp:Button ID="removebtn" class="btn-primary" runat="server" Text="Cancel Booking" OnClick="Cancel_Booking"/>
                     </ContentTemplate>
         </asp:UpdatePanel>
    </form>
	
<footer>
	<h2> Contact Us </h2>
	<p> Telephone Number: 145-423-8724 </p>
	<p> Email: info@royalrailways.com </p>
    <a href="Main Page.aspx" style="color:red; text-decoration:none;">Home</a> <br/> <br/>
    <a href="Booking.aspx" style="color:red; text-decoration:none;">Book</a> <br/> <br/>
    <a href="Experience.aspx" style="color:red; text-decoration:none;">Experience</a> <br/> <br/>
    <a href="Reward System.aspx" style="color:red; text-decoration:none;">Rewards</a> <br/> <br/>
	<a href="Staff.aspx" style="color:red; text-decoration:none;">Staff</a> <br/> <br/>
	<a href="Reviews.aspx" style="color:red; text-decoration:none;">Reviews</a> <br/> <br/>
    <p> All Terms and Conditions Applied </p>
</footer>
</body>
</html>