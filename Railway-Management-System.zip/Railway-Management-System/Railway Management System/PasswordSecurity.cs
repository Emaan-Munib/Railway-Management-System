using System;
using System.Security.Cryptography;

namespace Railway_Management_System
{
    // PBKDF2 password hashes: format PBKDF2$iterations$base64salt$base64hash.
    public static class PasswordSecurity
    {
        private const int Iterations = 120000;
        public static string Hash(string password)
        {
            byte[] salt = new byte[16];
            using (var rng = RandomNumberGenerator.Create()) rng.GetBytes(salt);
            using (var pbkdf2 = new Rfc2898DeriveBytes(password, salt, Iterations))
                return "PBKDF2$" + Iterations + "$" + Convert.ToBase64String(salt) + "$" + Convert.ToBase64String(pbkdf2.GetBytes(32));
        }
        public static bool Verify(string password, string encoded)
        {
            if (string.IsNullOrEmpty(encoded)) return false;
            var parts = encoded.Split('$');
            if (parts.Length != 4 || parts[0] != "PBKDF2") return false;
            int rounds;
            if (!int.TryParse(parts[1], out rounds) || rounds < 10000 || rounds > 1000000) return false;
            try
            {
                byte[] salt = Convert.FromBase64String(parts[2]);
                byte[] expected = Convert.FromBase64String(parts[3]);
                using (var pbkdf2 = new Rfc2898DeriveBytes(password, salt, rounds))
                {
                    byte[] actual = pbkdf2.GetBytes(expected.Length);
                    int diff = 0;
                    for (int i = 0; i < actual.Length; i++) diff |= actual[i] ^ expected[i];
                    return diff == 0;
                }
            }
            catch (FormatException) { return false; }
        }
    }
}
