﻿<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="Login.aspx.cs" Inherits="Railway_Management_System.Login" %>

<!DOCTYPE html>

<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <title>Login</title>
    <style>
    body {
        font-family: Arial, sans-serif;
        margin: 0;
        padding: 0;
        background-color: #1E0122;
		background-image:  linear-gradient(rgba(0,0,0,0.5),rgba(0,0,0,0.5)),url("https://i.pinimg.com/736x/0a/c9/aa/0ac9aa2ec5567e8aad7d16cd815b1f97.jpg");
        background-attachment: fixed;
		color: red;
    }
    .container {
        max-width: 400px;
        margin: 100px auto;
        padding: 20px;
        text-align: center;
    }
    h1 {
        margin-bottom: 20px;
    }
    .input-group {
        margin-bottom: 20px;
    }
    .input-group input {
        width: 100%;
        padding: 10px;
		background-color: black;
		color: white;
    }
    .btn {
        display: inline-block;
        padding: 10px 20px;
        color: #fff;
        text-decoration: none;
        border-radius: 5px;
		background-color: #6c5ce7; 
		border-color: #6c5ce7;
    }
    .btn:hover {
        background-color: #4834d4; 
		border-color: #4834d4;
    }
    .signup-link {
        display: block;
        margin-top: 20px;
        text-decoration: none;
        color: white;
    }
    .message {
    color: red;
    font-weight: bold;
    margin-top: 10px;
}
    </style>
</head>
<body>
    <form runat="server">
        <div class="container">
            <h1>Login</h1>
            <asp:Label ID="lblMessage" runat="server" CssClass="message" Text=""></asp:Label>
            <div class="input-group">
                <asp:TextBox runat="server" ID="txtEmail" placeholder="Email"></asp:TextBox>
            </div>
            <div class="input-group">
                <asp:TextBox runat="server" ID="txtPassword" TextMode="Password" placeholder="Password"></asp:TextBox>
            </div>
            <asp:Button runat="server" ID="btnLogin" Text="Login" CssClass="btn" OnClick="btnLogin_Click" />
            <a href="Sign Up.aspx" class="signup-link">Create a new Account | Sign up</a>
        </div>
    </form>
</body>
</html>