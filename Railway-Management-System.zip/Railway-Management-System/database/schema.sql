-- Railway Management System: clean schema for SQL Server / ASP.NET application
-- Run in SSMS on a local development instance. No personal records or passwords included.
IF DB_ID(N'RailwaySystem') IS NULL CREATE DATABASE RailwaySystem;
GO
USE RailwaySystem;
GO
CREATE TABLE Traveller (
 ID INT IDENTITY(1,1) PRIMARY KEY,
 FName NVARCHAR(100) NOT NULL,
 LName NVARCHAR(100) NOT NULL,
 PhoneNo NVARCHAR(20) NULL,
 Email NVARCHAR(100) NOT NULL UNIQUE,
 CNIC NVARCHAR(15) NULL,
 Password NVARCHAR(255) NOT NULL, -- PBKDF2 hash, never plaintext
 Points INT NOT NULL DEFAULT (0),
 Image NVARCHAR(255) NULL
);
GO
CREATE TABLE Schedule (
 RideID INT IDENTITY(1,1) PRIMARY KEY,
 Arrival NVARCHAR(100) NOT NULL,
 Destination NVARCHAR(100) NOT NULL,
 TravelDate DATE NOT NULL,
 TravelTime TIME NOT NULL,
 Available_Seats INT NOT NULL CHECK (Available_Seats >= 0),
 Distance INT NOT NULL
);
GO
CREATE TABLE Booking (
 BookingID INT IDENTITY(1,1) PRIMARY KEY,
 RideID INT NOT NULL REFERENCES Schedule(RideID),
 TravellerID INT NOT NULL REFERENCES Traveller(ID),
 Seats INT NOT NULL CHECK (Seats > 0),
 Class NVARCHAR(50) NOT NULL
);
GO
CREATE TABLE Reviews (
 ReviewID INT IDENTITY(1,1) PRIMARY KEY,
 TravellerID INT NOT NULL REFERENCES Traveller(ID),
 Name NVARCHAR(100) NOT NULL,
 SubmittedDate DATETIME NOT NULL,
 Text NVARCHAR(MAX) NOT NULL
);
GO
CREATE TABLE Experience (
 TrainID INT PRIMARY KEY, TrainName NVARCHAR(100) NOT NULL,
 SourceStation NVARCHAR(100) NOT NULL, DestinationStation NVARCHAR(100) NOT NULL,
 DepartureTime TIME NOT NULL, ArrivalTime TIME NOT NULL,
 Duration INT NOT NULL, Fare DECIMAL(10,2) NOT NULL
);
GO
CREATE TABLE Staff (
 StaffID INT PRIMARY KEY, Username NVARCHAR(100) NOT NULL,
 Password NVARCHAR(255) NOT NULL, Email NVARCHAR(100) NOT NULL UNIQUE,
 PhoneNumber NVARCHAR(15) NOT NULL UNIQUE, Role NVARCHAR(20) NOT NULL
);
GO
CREATE TABLE TrainCategories (CategoryID INT IDENTITY(1,1) PRIMARY KEY, CategoryName NVARCHAR(100) NOT NULL);
GO
CREATE TABLE TrainDetails (
 TrainID INT IDENTITY(1,1) PRIMARY KEY, CategoryID INT NOT NULL REFERENCES TrainCategories(CategoryID),
 TrainName NVARCHAR(100) NOT NULL, Description NVARCHAR(MAX) NOT NULL, ImageURL NVARCHAR(255) NOT NULL
);
GO
CREATE TABLE Destinations (
 DestinationID INT IDENTITY(1,1) PRIMARY KEY, DestinationName NVARCHAR(100) NOT NULL,
 Description NVARCHAR(MAX) NOT NULL, ImageURL NVARCHAR(255) NOT NULL
);
GO
CREATE TABLE TrainDestinations (
 TrainID INT NOT NULL REFERENCES TrainDetails(TrainID),
 DestinationID INT NOT NULL REFERENCES Destinations(DestinationID),
 CONSTRAINT PK_TrainDestinations PRIMARY KEY (TrainID, DestinationID)
);
GO
-- Fictional route examples; update dates for current bookings.
INSERT INTO Schedule (Arrival, Destination, TravelDate, TravelTime, Available_Seats, Distance)
VALUES (N'Lahore', N'Islamabad', DATEADD(day, 7, CAST(GETDATE() AS date)), '14:00', 80, 300),
       (N'Gojra', N'Lahore', DATEADD(day, 8, CAST(GETDATE() AS date)), '18:00', 40, 350),
       (N'Faisalabad', N'Islamabad', DATEADD(day, 9, CAST(GETDATE() AS date)), '20:00', 60, 500);
GO
